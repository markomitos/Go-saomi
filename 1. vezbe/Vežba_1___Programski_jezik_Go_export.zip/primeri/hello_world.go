package main // deklaracija paketa

import "fmt" // paket za standardni ulaz / izlaz

// ulazna tacka programa
func main () {
	fmt.Println("Hello World from Go")
}
