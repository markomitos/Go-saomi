package main

import "examples/quote"

func main() {
	quote.PrintQuote()
}
